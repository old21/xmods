package com.mayakplay.cscase.network;

/**
 * Created by Константин on 10.01.2016.
 */
public class Recieve {

    public static String CASES_LIST = "";
    public static String CURRENT_CASE_ITEMS_LIST = "1,0,1,1,0,2,1,0,3,1,0,4,1,0,5";


    public static String WON_ITEM = "1,0,1,5";
    public static String MOTD_IMG = "";

    public static boolean isRolling = false;

}
