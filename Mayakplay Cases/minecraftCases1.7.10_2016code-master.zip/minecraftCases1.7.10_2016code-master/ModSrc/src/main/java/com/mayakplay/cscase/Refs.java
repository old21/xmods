package com.mayakplay.cscase;

/**
 * Created by Константин on 06.01.2016.
 */
public class Refs {

    public static final String MOD_ID = "teccs";
    public static final String MOD_NAME = "Mayakplay Cases";
    public static final String MOD_VERSION = "1.0.0";

}
