package com.mayakplay.cscase;

/**
 * Created by Константин on 11.01.2016.
 */
public class Strings {

    public static String itemsCanDrop = "\u041F\u0440\u0435\u0434\u043C\u0435\u0442\u044B, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u043C\u043E\u0433\u0443\u0442 \u0432\u044B\u043F\u0430\u0441\u0442\u044C:";
    public static String continueOK = "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C";
    public static String opening = "\u041E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u043C...";
    public static String view = "\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440";
    public static String price = "\u0426\u0435\u043D\u0430: ";

    public static String openPrice(int price) {
        return "\u041E\u0442\u043A\u0440\u044B\u0442\u044C - " + price + " \u2726";
    }

}
