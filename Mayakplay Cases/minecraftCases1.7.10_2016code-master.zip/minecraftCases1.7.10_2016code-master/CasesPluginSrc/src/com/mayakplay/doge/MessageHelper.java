package com.mayakplay.doge;

/**
 * Created by Константин on 10.01.2016.
 */
public class MessageHelper {
}
