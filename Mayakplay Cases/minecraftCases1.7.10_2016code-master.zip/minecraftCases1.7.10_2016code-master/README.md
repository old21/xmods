# Minecraft Cases (Слив моего говнокода из 2016го)

Информация для русскоязычных пользователей, пишущих мне в вк: 
-----
 - Я не веду поддержку данного мода, я слил его, чтобы бездарные дауничи не зарабатывали на моей декомпилированной работе.
 - Дорабатывать его я не буду даже за "две сотки",  "пятишечку", либо "кэсик"!

Config
------
```yml
Cases:
  - CASE_NAME, CASE_PRICE, TEXTURE_IMAGE_URL
CaseItems: 
  - MINECRAFT_ITEM_ID, MINECRAFT_ITEM_SUB_ID, RARITY (1-5), MIN_DROP_COUNT, MAX_DROP_COUNT, CASE_ID (from 0)
```
Screenshots 
------
<img src="https://pp.userapi.com/c638116/v638116748/31413/y8yL2D7VXM0.jpg" align="left" height="250">
<img src="https://pp.userapi.com/c638116/v638116748/31423/TnFZ0s4p34g.jpg" align="left" height="250">
<img src="https://pp.userapi.com/c638116/v638116459/335ad/TsKK7nvLu2o.jpg" align="left" height="250">
<img src="https://pp.userapi.com/c638116/v638116748/30fad/DQD2mMet-Us.jpg" align="center" height="350">
